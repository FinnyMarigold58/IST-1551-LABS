﻿// IST 1551 Lab 1, Tegan Herring, 09/12/2025
// Textbook Challenge Consolas and Telim Pg. 26

Console.WriteLine("Bread is ready.");

Console.WriteLine("Who is the bread for?");
string name = Console.ReadLine();

Console.WriteLine("Noted: " + name + " got bread.");